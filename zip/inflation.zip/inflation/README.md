Annual growth rate of the GDP implicit deflator and Inflation measured by the consumer price index

## Data

Data source unknown. This data will not be updated. Do not use the data for analysis.

## Known usage

No known usage

## License

No known copyright. [Contact us](https://github.com/frictionlessdata/example-data-packages/issues/new) if you are aware of any copyright in the data.

This data package is available under [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/).
