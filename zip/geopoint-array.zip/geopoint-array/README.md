A single csv file with location defined by:

- `type: geojson`
- `format: array`

This package supports the [example](https://frictionlessdata.io/guides/point-location-data/#2.-geopoint-array) given in the Frictionless Data [Point location data in CSV files](https://frictionlessdata.io/guides/point-location-data/) guide.
