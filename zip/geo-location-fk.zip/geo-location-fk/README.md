A single csv file with location defined by a String and Foreign key reference to well-known place-name

This package supports the [example](https://frictionlessdata.io/guides/point-location-data/#5.-string-and-foreign-key-reference-to-well-known-place-name
) given in the Frictionless Data [Point location data in CSV files](https://frictionlessdata.io/guides/point-location-data/) guide.
