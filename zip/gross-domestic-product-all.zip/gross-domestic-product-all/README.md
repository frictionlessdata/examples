@todo

Every data package must have a `README.md`. The `README.md` should follow [good practices](https://frictionlessdata.io/guides/publish-faq/#readme).

Use the [`README-template.md`](resources/README-template.md) to kick start writing a `README.md` for this data package.
