A single csv file with location defined by:

- `type: geojson`
- `format: object`

This package supports the [example](https://frictionlessdata.io/guides/point-location-data/#3.-geopoint-object) given in the Frictionless Data [Point location data in CSV files](https://frictionlessdata.io/guides/point-location-data/) guide.
