Example Geo [Data Package][] showing how to package up GeoJSON data.

[Data Package]: http://data.okfn.org/doc/data-package

