Data package that references data via a URL
