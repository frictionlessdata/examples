Data package that references its data, schema and dialect via URLs
