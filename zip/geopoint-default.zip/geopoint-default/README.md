A single csv file with location defined by:

- `type: geojson`
- `format: default`

This package supports the [example](https://frictionlessdata.io/guides/point-location-data/#1.-geopoint-default) given in the Frictionless Data [Point location data in CSV files](https://frictionlessdata.io/guides/point-location-data/) guide.
