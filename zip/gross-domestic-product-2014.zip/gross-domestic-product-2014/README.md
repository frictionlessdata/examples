Example Data Package providing Country, regional and world GDP in current US Dollars ($) for 2014

## Data

Data source unknown. This data will not be updated. Do not use the data for analysis.

## Known usage

This data package is used in the Frictionless Data [Field Guide](https://frictionlessdata.io/field-guide/) and [Documentation](https://frictionlessdata.io/docs/)

## License

No known copyright. [Contact us](https://github.com/frictionlessdata/example-data-packages/issues/new) if you are aware of any copyright in the data.

This data package is available under [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/).
