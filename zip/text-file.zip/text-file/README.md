An example of a txt file providing non-tabular data inside a data package.

The data is an example. Do not buy a lottery ticket based on this data.
