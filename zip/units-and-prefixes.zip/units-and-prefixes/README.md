These tables represent the values for units and their prefixes as specified in the draft [Units specification](http://specs.okfnlabs.org/units/). It contains:

- An inventory of standard units with unique identifiers
- A set of unit prefixes
