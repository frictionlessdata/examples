A Foreign Key example linking two CSV files in the same data package

